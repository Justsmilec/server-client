package com.example.HomeAppliance.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Attributes-DB" )
public class Attributes {
    @Id
    private String attributeId;
    private String name;
    private int min;
    private int max;
    private int current;

    public Attributes() {
    }

    public Attributes(String attributeId, String name, int min, int max, int current) {
        this.attributeId = attributeId;
        this.name = name;
        this.min = min;
        this.max = max;
        this.current = current;
    }

    public String getId() {
        return attributeId;
    }

    public void setId(String id) {
        this.attributeId = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public int getCurrent() {
        return current;
    }

    public void setCurrent(int current) {
        this.current = current;
    }


    @Override
    public String toString() {
        return "Attributes{" +
                "attributeId='" + attributeId + '\'' +
                ", name='" + name + '\'' +
                ", min=" + min +
                ", max=" + max +
                ", current=" + current +
                '}';
    }
}


