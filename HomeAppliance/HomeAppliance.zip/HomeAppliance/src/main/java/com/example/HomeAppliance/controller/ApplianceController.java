package com.example.HomeAppliance.controller;

import com.example.HomeAppliance.model.Appliance;
import com.example.HomeAppliance.model.Attributes;
import com.example.HomeAppliance.service.ApplianceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/home")
public class ApplianceController {
    @Autowired
    private ApplianceService service;


    @GetMapping("/get")
    public List<Appliance> getAppliance() {
        List<Appliance> appliances = service.getAppliances();
         return appliances;
    }

    @GetMapping("turnOnOff/{id}")
    public List<Appliance> turnOnOffAppliance(@PathVariable("id") String id) {
        List<Appliance> appliances = service.turnOnOffAppliance(id);
        return appliances;
    }

    @PostMapping("/add")
    public String addAppliance(@RequestBody Appliance appliance) {
         service.addAppliance(appliance);
         return "added";
    }



    @GetMapping("increase/{attributeId}")
    public List<Appliance> increaseAttributeValue(@PathVariable("attributeId") String attributeId) {
        service.increaseAttributeValue(attributeId);
        return service.getAppliances();
    }

    @GetMapping("decrease/{id}")
    public List<Appliance> decreaseAttributeValue(@PathVariable("attributeId") String attributeId) {
        service.decreaseAttributeValue(attributeId);
        return service.getAppliances();
    }

}









