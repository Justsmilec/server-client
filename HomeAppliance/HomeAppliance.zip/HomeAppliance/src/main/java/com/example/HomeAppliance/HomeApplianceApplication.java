package com.example.HomeAppliance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeApplianceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeApplianceApplication.class, args);
	}

}
