package com.example.HomeAppliance.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "Appliance-DB" )
public class Appliance {

    @Id
    private String id;
    private String name;
    private int state;
    private String type;
    private String location;
    private List<Attributes> attributes;            // one-to-many, a device can have one or more attributes


    public Appliance() {
    }

    public Appliance(String id, String name, int state, String type, String location, List<Attributes> attributes) {
        this.id = id;
        this.name = name;
        this.state = state;
        this.type = type;
        this.location = location;
        this.attributes = attributes;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Appliance(String name, int state) {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public List<Attributes> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<Attributes> attributes) {
        this.attributes = attributes;
    }

    @Override
    public String toString() {
        return "Appliance{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", state=" + state +
                ", type=" + type +
                ", location=" + location +
                ", attributes=" + attributes +
                '}';
    }
}


