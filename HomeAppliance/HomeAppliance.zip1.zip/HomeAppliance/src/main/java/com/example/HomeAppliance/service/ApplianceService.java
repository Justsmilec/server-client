package com.example.HomeAppliance.service;

import com.example.HomeAppliance.model.Appliance;
import com.example.HomeAppliance.model.Attributes;
import com.example.HomeAppliance.repository.ApplianceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.List;

@Service
public class ApplianceService {

    private final Class<Attributes> attributesClass = Attributes.class;
    @Autowired
    private ApplianceRepository repository;

    public List<Appliance> getAppliances(){
        return repository.findAll();
    }

    public Appliance addAppliance(Appliance appliance) {
        return repository.save(appliance);
    }


    public List<Appliance> turnOnOffAppliance(String id) {

       Appliance appliance = repository.findById(id).get();
        if(appliance.getState()==1) {
            appliance.setState(0);
        } else if(appliance.getState()==0) {
            appliance.setState(1);
        }
        repository.save(appliance);
        return repository.findAll();
    }


    public void increaseAttributeValue(String attributeId) {

       Appliance appliance = repository.findById(attributeId).get();

    }



    public void decreaseAttributeValue(String attributeId) {

        Appliance appliance = repository.findById(attributeId).get();

    }

}
